// ==========================================
// NS CODE STORE - Complete Script v3.0
// Part 1: Data, Products, Cart, Navigation
// ==========================================

// ========== DATA STORAGE ==========
let cart = JSON.parse(localStorage.getItem('nsCart')) || [];
let orders = JSON.parse(localStorage.getItem('nsOrders')) || [];
let products = JSON.parse(localStorage.getItem('nsProducts')) || getDefaultProducts();
let adminLoggedIn = sessionStorage.getItem('nsAdminLogin') === 'true';
const ADMIN_PASSWORD = 'NSAdmin143';

// ========== DEFAULT PRODUCTS ==========
function getDefaultProducts() {
    return [
        { 
            id: 1, 
            name: 'Modern Dashboard', 
            category: 'html', 
            desc: 'Admin dashboard with charts', 
            price: 1499, 
            salePrice: 999, 
            icon: '📊', 
            featured: true, 
            file: 'dashboard.zip',
            downloadLink: ''
        },
        { 
            id: 2, 
            name: 'Portfolio Template', 
            category: 'html', 
            desc: 'Developer portfolio website', 
            price: 799, 
            salePrice: 499, 
            icon: '🎨', 
            featured: true, 
            file: 'portfolio.zip',
            downloadLink: ''
        },
        { 
            id: 3, 
            name: 'React E-Commerce', 
            category: 'react', 
            desc: 'Full shopping app', 
            price: 2499, 
            salePrice: 1999, 
            icon: '🛍️', 
            featured: false, 
            file: 'ecommerce.zip',
            downloadLink: ''
        },
        { 
            id: 4, 
            name: 'Snake Game', 
            category: 'game', 
            desc: 'Classic snake game', 
            price: 299, 
            salePrice: 199, 
            icon: '🐍', 
            featured: true, 
            file: 'snake.zip',
            downloadLink: ''
        },
        { 
            id: 5, 
            name: 'Weather Widget', 
            category: 'tool', 
            desc: '7-day forecast app', 
            price: 399, 
            salePrice: 299, 
            icon: '🌤️', 
            featured: false, 
            file: 'weather.zip',
            downloadLink: ''
        },
        { 
            id: 6, 
            name: 'Chat App', 
            category: 'react', 
            desc: 'Real-time messaging', 
            price: 1999, 
            salePrice: 1499, 
            icon: '💬', 
            featured: false, 
            file: 'chat.zip',
            downloadLink: ''
        }
    ];
}

// ========== SAVE DATA ==========
function saveAll() {
    localStorage.setItem('nsCart', JSON.stringify(cart));
    localStorage.setItem('nsOrders', JSON.stringify(orders));
    localStorage.setItem('nsProducts', JSON.stringify(products));
}

// ========== NOTIFICATION ==========
function showNotif(msg, type) {
    var n = document.createElement('div');
    n.className = 'notification';
    if (type === 'success') n.classList.add('notif-success');
    else if (type === 'error') n.classList.add('notif-error');
    else n.classList.add('notif-info');
    n.textContent = msg;
    document.body.appendChild(n);
    setTimeout(function() { n.remove(); }, 3000);
}

// ========== PAGE NAVIGATION ==========
function showPage(page) {
    var allPages = document.querySelectorAll('.page');
    for (var i = 0; i < allPages.length; i++) {
        allPages[i].classList.remove('active');
    }
    
    if (page === 'home') document.getElementById('homePage').classList.add('active');
    if (page === 'products') document.getElementById('productsPage').classList.add('active');
    if (page === 'orders') document.getElementById('ordersPage').classList.add('active');
    
    if (page === 'products') showProducts();
    if (page === 'orders') showMyOrders();
}

// ========== SHOW PRODUCTS ==========
function showProducts() {
    var categoryFilter = document.getElementById('categoryFilter');
    var category = categoryFilter ? categoryFilter.value : 'all';
    
    var searchBox = document.getElementById('searchBox');
    var search = searchBox ? searchBox.value.toLowerCase() : '';
    
    var filtered = [];
    for (var i = 0; i < products.length; i++) {
        var p = products[i];
        var matchCategory = (category === 'all' || p.category === category);
        var matchSearch = true;
        if (search !== '') {
            matchSearch = (p.name.toLowerCase().indexOf(search) !== -1) || 
                         (p.desc.toLowerCase().indexOf(search) !== -1);
        }
        if (matchCategory && matchSearch) {
            filtered.push(p);
        }
    }
    
    // Featured Products
    var featured = [];
    for (var j = 0; j < products.length; j++) {
        if (products[j].featured) {
            featured.push(products[j]);
        }
    }
    
    var featuredHTML = '';
    for (var k = 0; k < featured.length; k++) {
        featuredHTML += makeProductCard(featured[k]);
    }
    var featuredDiv = document.getElementById('featuredProducts');
    if (featuredDiv) {
        featuredDiv.innerHTML = featuredHTML || '<p style="color:#94a3b8;text-align:center;">No featured products</p>';
    }
    
    // All Products
    var allHTML = '';
    for (var l = 0; l < filtered.length; l++) {
        allHTML += makeProductCard(filtered[l]);
    }
    var allDiv = document.getElementById('allProducts');
    if (allDiv) {
        allDiv.innerHTML = allHTML || '<p style="text-align:center;color:#94a3b8;padding:30px;">No products found</p>';
    }
}

// ========== PRODUCT CARD HTML ==========
function makeProductCard(p) {
    var price = p.salePrice || p.price;
    var oldPriceHTML = '';
    if (p.salePrice) {
        oldPriceHTML = '<span class="old-price">₹' + p.price + '</span>';
    }
    
    var html = '';
    html += '<div class="product-card">';
    html += '<div class="product-icon">' + p.icon + '</div>';
    html += '<span class="product-category">' + p.category.toUpperCase() + '</span>';
    html += '<h3 class="product-name">' + p.name + '</h3>';
    html += '<p class="product-desc">' + p.desc + '</p>';
    html += '<div class="product-price">';
    html += '<div><span class="price">₹' + price + '</span>' + oldPriceHTML + '</div>';
    html += '<button class="buy-btn" onclick="addToCart(' + p.id + ')">Add to Cart</button>';
    html += '</div></div>';
    
    return html;
}

// ========== CART FUNCTIONS ==========
function addToCart(productId) {
    var product = null;
    for (var i = 0; i < products.length; i++) {
        if (products[i].id === productId) {
            product = products[i];
            break;
        }
    }
    if (!product) return;
    
    var existingItem = null;
    for (var j = 0; j < cart.length; j++) {
        if (cart[j].id === productId) {
            existingItem = cart[j];
            break;
        }
    }
    
    if (existingItem) {
        existingItem.qty = existingItem.qty + 1;
    } else {
        cart.push({
            id: productId,
            name: product.name,
            price: product.salePrice || product.price,
            icon: product.icon,
            qty: 1
        });
    }
    
    saveAll();
    updateCartUI();
    showNotif(product.name + ' added to cart!', 'success');
}

function removeFromCart(productId) {
    var newCart = [];
    for (var i = 0; i < cart.length; i++) {
        if (cart[i].id !== productId) {
            newCart.push(cart[i]);
        }
    }
    cart = newCart;
    saveAll();
    updateCartUI();
}

function updateCartUI() {
    var count = 0;
    var total = 0;
    for (var i = 0; i < cart.length; i++) {
        count = count + cart[i].qty;
        total = total + (cart[i].price * cart[i].qty);
    }
    
    var cartCountEl = document.getElementById('cartCount');
    var cartTotalEl = document.getElementById('cartTotal');
    var cartItemsEl = document.getElementById('cartItems');
    
    if (cartCountEl) cartCountEl.textContent = count;
    if (cartTotalEl) cartTotalEl.textContent = total;
    
    if (cartItemsEl) {
        if (cart.length === 0) {
            cartItemsEl.innerHTML = '<p style="color:#94a3b8;text-align:center;padding:30px;">Cart is empty</p>';
        } else {
            var html = '';
            for (var j = 0; j < cart.length; j++) {
                var item = cart[j];
                html += '<div class="cart-item">';
                html += '<div><strong>' + item.icon + ' ' + item.name + '</strong><br>';
                html += '<small style="color:#94a3b8;">₹' + item.price + ' × ' + item.qty + ' = ₹' + (item.price * item.qty) + '</small></div>';
                html += '<button onclick="removeFromCart(' + item.id + ')" style="background:#ef4444;color:white;border:none;padding:5px 10px;border-radius:5px;cursor:pointer;">✕</button>';
                html += '</div>';
            }
            cartItemsEl.innerHTML = html;
        }
    }
}

function openCart() {
    document.getElementById('cartSidebar').classList.add('active');
    document.getElementById('cartOverlay').classList.add('active');
    updateCartUI();
}

function closeCart() {
    document.getElementById('cartSidebar').classList.remove('active');
    document.getElementById('cartOverlay').classList.remove('active');
}
// ==========================================
// NS CODE STORE - Part 2: Checkout, Orders & Download
// ==========================================

// ========== CHECKOUT ==========
function checkout() {
    if (cart.length === 0) {
        showNotif('Cart is empty! Add products first.', 'error');
        return;
    }
    
    var total = 0;
    for (var i = 0; i < cart.length; i++) {
        total = total + (cart[i].price * cart[i].qty);
    }
    
    var html = '';
    
    // Order Summary
    html += '<h4 style="margin-bottom:15px;">📋 Order Summary</h4>';
    
    for (var j = 0; j < cart.length; j++) {
        var item = cart[j];
        html += '<div style="display:flex;justify-content:space-between;padding:5px 0;">';
        html += '<span>' + item.icon + ' ' + item.name + ' × ' + item.qty + '</span>';
        html += '<span>₹' + (item.price * item.qty) + '</span>';
        html += '</div>';
    }
    
    html += '<hr style="border-color:#334155;margin:15px 0;">';
    html += '<h3 style="color:#3b82f6;">Total: ₹' + total + '</h3>';
    
    // UPI Payment Section
    html += '<div style="background:#0f172a;padding:20px;border-radius:8px;margin:20px 0;">';
    html += '<h4 style="color:#10b981;">📱 Pay via UPI</h4>';
    html += '<p style="font-size:22px;color:#3b82f6;margin:10px 0;"><strong>nscodestore@upi</strong></p>';
    html += '<button onclick="copyUPI()" style="background:#334155;color:white;border:none;padding:8px 15px;border-radius:6px;cursor:pointer;">📋 Copy UPI ID</button>';
    html += '<p style="color:#94a3b8;font-size:12px;margin-top:10px;">Pay the exact amount and upload screenshot below</p>';
    html += '</div>';
    
    // Screenshot Upload
    html += '<div class="upload-box" id="screenshotBox">';
    html += '<p>📸 Tap to Upload Payment Screenshot</p>';
    html += '<input type="file" id="screenshotInput" accept="image/*" onchange="previewScreenshot(this)" style="display:none;">';
    html += '<img id="screenshotPreview" style="display:none;max-width:200px;margin-top:10px;border-radius:8px;">';
    html += '</div>';
    
    // UPI ID Input
    html += '<div class="form-group">';
    html += '<label>Your UPI ID (optional)</label>';
    html += '<input type="text" id="userUpiId" placeholder="yourname@upi" style="width:100%;padding:10px;background:#0f172a;border:1px solid #334155;color:white;border-radius:6px;">';
    html += '</div>';
    
    // Submit Button
    html += '<button onclick="submitOrder()" style="width:100%;background:#10b981;color:white;border:none;padding:15px;border-radius:8px;font-size:16px;cursor:pointer;font-weight:bold;">';
    html += '✅ Submit Payment for Verification';
    html += '</button>';
    
    html += '<p style="color:#94a3b8;font-size:12px;text-align:center;margin-top:10px;">Admin will verify within 5-10 minutes</p>';
    
    document.getElementById('checkoutContent').innerHTML = html;
    document.getElementById('checkoutModal').classList.add('active');
    closeCart();
    
    // Screenshot upload click event
    setTimeout(function() {
        var box = document.getElementById('screenshotBox');
        var input = document.getElementById('screenshotInput');
        if (box && input) {
            box.onclick = function() {
                input.click();
            };
        }
    }, 300);
}

// ========== COPY UPI ID ==========
function copyUPI() {
    navigator.clipboard.writeText('nscodestore@upi').then(function() {
        showNotif('✅ UPI ID copied!', 'success');
    }).catch(function() {
        showNotif('Failed to copy. UPI ID: nscodestore@upi', 'error');
    });
}

// ========== PREVIEW SCREENSHOT ==========
function previewScreenshot(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function(e) {
            var img = document.getElementById('screenshotPreview');
            img.src = e.target.result;
            img.style.display = 'block';
        };
        reader.readAsDataURL(input.files[0]);
    }
}

// ========== CLOSE CHECKOUT ==========
function closeCheckout() {
    document.getElementById('checkoutModal').classList.remove('active');
}

// ========== SUBMIT ORDER ==========
function submitOrder() {
    var screenshotInput = document.getElementById('screenshotInput');
    var userUpiId = document.getElementById('userUpiId').value;
    
    // Check if screenshot is uploaded
    if (!screenshotInput.files || !screenshotInput.files[0]) {
        showNotif('❌ Please upload payment screenshot!', 'error');
        return;
    }
    
    var reader = new FileReader();
    reader.onload = function(e) {
        // Calculate total
        var total = 0;
        var itemsCopy = [];
        
        for (var i = 0; i < cart.length; i++) {
            total = total + (cart[i].price * cart[i].qty);
            itemsCopy.push({
                id: cart[i].id,
                name: cart[i].name,
                price: cart[i].price,
                icon: cart[i].icon,
                qty: cart[i].qty
            });
        }
        
        // Create order object
        var order = {
            id: 'NSC' + Date.now(),
            date: new Date().toLocaleString(),
            items: itemsCopy,
            total: total,
            screenshot: e.target.result,
            userUpiId: userUpiId,
            status: 'pending'
        };
        
        // Add to orders array
        orders.unshift(order);
        
        // Clear cart
        cart = [];
        saveAll();
        updateCartUI();
        closeCheckout();
        
        // Show success message
        showNotif('✅ Order #' + order.id + ' submitted! Wait for admin approval.', 'success');
        
        // Go to orders page
        showPage('orders');
    };
    
    reader.readAsDataURL(screenshotInput.files[0]);
}

// ========== SHOW MY ORDERS ==========
function showMyOrders() {
    var container = document.getElementById('myOrdersList');
    
    if (orders.length === 0) {
        container.innerHTML = '<p style="text-align:center;color:#94a3b8;padding:30px;">No orders yet</p>';
        return;
    }
    
    var html = '';
    
    for (var i = 0; i < orders.length; i++) {
        var order = orders[i];
        
        html += '<div class="order-card">';
        
        // Order header
        html += '<div style="display:flex;justify-content:space-between;align-items:start;">';
        html += '<div><h4>Order #' + order.id + '</h4>';
        html += '<small style="color:#94a3b8;">📅 ' + order.date + '</small></div>';
        
        // Status badge
        var statusClass = 'status-' + order.status;
        html += '<span class="' + statusClass + '">' + order.status.toUpperCase() + '</span>';
        html += '</div>';
        
        // Order items
        html += '<div style="margin:15px 0;background:#0f172a;padding:12px;border-radius:8px;">';
        
        for (var j = 0; j < order.items.length; j++) {
            var item = order.items[j];
            html += '<div style="display:flex;justify-content:space-between;padding:3px 0;">';
            html += '<span>' + item.icon + ' ' + item.name + ' × ' + item.qty + '</span>';
            html += '<span style="color:#3b82f6;">₹' + (item.price * item.qty) + '</span>';
            html += '</div>';
        }
        
        html += '<hr style="border-color:#334155;margin:8px 0;">';
        html += '<div style="display:flex;justify-content:space-between;">';
        html += '<strong>Total:</strong>';
        html += '<strong style="color:#10b981;">₹' + order.total + '</strong>';
        html += '</div></div>';
        
        // Screenshot
        if (order.screenshot) {
            html += '<div>';
            html += '<small style="color:#94a3b8;">Payment Screenshot:</small>';
            html += '<img src="' + order.screenshot + '" style="max-width:150px;display:block;border-radius:8px;margin-top:5px;cursor:pointer;" onclick="window.open(this.src)">';
            html += '</div>';
        }
        
        // Status actions
        if (order.status === 'approved') {
            html += '<div style="background:rgba(16,185,129,0.1);padding:12px;border-radius:8px;margin-top:12px;">';
            html += '<p style="color:#10b981;">✅ Payment Verified! Your files are ready.</p>';
            html += '<button onclick="downloadFiles(\'' + order.id + '\')" style="background:#3b82f6;color:white;border:none;padding:10px 20px;border-radius:6px;margin-top:5px;cursor:pointer;">📥 Download Files</button>';
            html += '</div>';
        } else if (order.status === 'pending') {
            html += '<p style="color:#f59e0b;margin-top:10px;">⏳ Waiting for admin verification...</p>';
        } else if (order.status === 'rejected') {
            html += '<p style="color:#ef4444;margin-top:10px;">❌ Payment rejected.</p>';
            if (order.reason) {
                html += '<p style="color:#94a3b8;font-size:13px;">Reason: ' + order.reason + '</p>';
            }
            html += '<p style="color:#94a3b8;font-size:13px;">Please contact support or try again.</p>';
        }
        
        html += '</div>';
    }
    
    container.innerHTML = html;
}

// ========== DOWNLOAD FILES (GOOGLE DRIVE SUPPORT) ==========
function downloadFiles(orderId) {
    var order = null;
    for (var i = 0; i < orders.length; i++) {
        if (orders[i].id === orderId) {
            order = orders[i];
            break;
        }
    }
    
    if (!order || order.status !== 'approved') {
        showNotif('❌ Order not approved yet!', 'error');
        return;
    }
    
    var downloaded = 0;
    
    for (var j = 0; j < order.items.length; j++) {
        var product = null;
        for (var k = 0; k < products.length; k++) {
            if (products[k].id === order.items[j].id) {
                product = products[k];
                break;
            }
        }
        
        if (product && product.downloadLink) {
            // Open Google Drive link in new tab
            window.open(product.downloadLink, '_blank');
            downloaded++;
            showNotif('📥 Opening: ' + product.name, 'success');
        } else if (product && !product.downloadLink) {
            showNotif('⚠️ No download link for: ' + product.name, 'error');
        }
    }
    
    if (downloaded > 0) {
        showNotif('✅ ' + downloaded + ' file(s) downloading! Check new tabs.', 'success');
    } else {
        showNotif('❌ No download links found! Contact support.', 'error');
    }
}
// ==========================================
// NS CODE STORE - Part 3: Admin Panel & Product Management
// ==========================================

// ========== ADMIN TOGGLE ==========
function toggleAdmin() {
    if (adminLoggedIn) {
        adminLoggedIn = false;
        sessionStorage.removeItem('nsAdminLogin');
        document.getElementById('adminBtn').textContent = '🔐 Admin';
        document.getElementById('adminBtn').style.background = '#3b82f6';
        showPage('home');
        showNotif('Admin logged out', 'info');
    } else {
        showAdminLogin();
    }
}

// ========== ADMIN LOGIN MODAL ==========
function showAdminLogin() {
    var modal = document.createElement('div');
    modal.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.85);z-index:2000;display:flex;justify-content:center;align-items:center;';
    modal.id = 'adminLoginModal';
    
    var innerHTML = '';
    innerHTML += '<div style="background:#1e293b;padding:30px;border-radius:12px;max-width:400px;width:90%;border:1px solid #334155;">';
    innerHTML += '<h3 style="color:#3b82f6;margin-bottom:20px;">🔐 Admin Login</h3>';
    innerHTML += '<div class="form-group">';
    innerHTML += '<label style="color:#94a3b8;">Enter Admin Password</label>';
    innerHTML += '<input type="password" id="adminPassInput" placeholder="Enter password..." style="width:100%;padding:12px;background:#0f172a;border:1px solid #334155;color:white;border-radius:8px;font-size:16px;">';
    innerHTML += '</div>';
    innerHTML += '<p id="loginErr" style="color:#ef4444;display:none;margin-bottom:10px;">❌ Wrong password!</p>';
    innerHTML += '<button onclick="verifyAdmin()" style="width:100%;background:#10b981;color:white;border:none;padding:12px;border-radius:8px;font-size:16px;cursor:pointer;font-weight:bold;">Login as Admin</button>';
    innerHTML += '<button onclick="closeAdminLogin()" style="width:100%;background:#334155;color:white;border:none;padding:10px;border-radius:8px;margin-top:10px;cursor:pointer;">Cancel</button>';
    innerHTML += '<p style="color:#64748b;font-size:12px;text-align:center;margin-top:15px;">Only store owner can access</p>';
    innerHTML += '</div>';
    
    modal.innerHTML = innerHTML;
    document.body.appendChild(modal);
    
    modal.addEventListener('click', function(e) {
        if (e.target === modal) {
            modal.remove();
        }
    });
    
    setTimeout(function() {
        var input = document.getElementById('adminPassInput');
        if (input) input.focus();
    }, 200);
}

function closeAdminLogin() {
    var modal = document.getElementById('adminLoginModal');
    if (modal) modal.remove();
}

// ========== VERIFY ADMIN PASSWORD ==========
function verifyAdmin() {
    var password = document.getElementById('adminPassInput').value;
    
    if (password === ADMIN_PASSWORD) {
        adminLoggedIn = true;
        sessionStorage.setItem('nsAdminLogin', 'true');
        
        var modal = document.getElementById('adminLoginModal');
        if (modal) modal.remove();
        
        document.getElementById('adminBtn').textContent = '🔓 Exit Admin';
        document.getElementById('adminBtn').style.background = '#10b981';
        
        showAdminPage();
        showNotif('✅ Welcome Admin!', 'success');
    } else {
        document.getElementById('loginErr').style.display = 'block';
        document.getElementById('adminPassInput').value = '';
        document.getElementById('adminPassInput').focus();
    }
}

// ========== SHOW ADMIN PAGE ==========
function showAdminPage() {
    if (!adminLoggedIn) {
        showAdminLogin();
        return;
    }
    
    var allPages = document.querySelectorAll('.page');
    for (var i = 0; i < allPages.length; i++) {
        allPages[i].classList.remove('active');
    }
    document.getElementById('adminPage').classList.add('active');
    showAdminTab('orders');
}

// ========== ADMIN TABS ==========
function showAdminTab(tab) {
    if (!adminLoggedIn) return;
    
    var tabs = document.querySelectorAll('.admin-tabs button');
    for (var i = 0; i < tabs.length; i++) {
        tabs[i].classList.remove('active-tab');
    }
    
    if (tab === 'orders' && tabs[0]) tabs[0].classList.add('active-tab');
    if (tab === 'products' && tabs[1]) tabs[1].classList.add('active-tab');
    if (tab === 'users' && tabs[2]) tabs[2].classList.add('active-tab');
    if (tab === 'stats' && tabs[3]) tabs[3].classList.add('active-tab');
    
    var content = document.getElementById('adminContent');
    
    if (tab === 'orders') showAdminOrders();
    if (tab === 'products') showAdminProducts();
    if (tab === 'users') showAdminUsers();
    if (tab === 'stats') showAdminStats();
}

// ========== ADMIN ORDERS ==========
function showAdminOrders() {
    var content = document.getElementById('adminContent');
    var pendingOrders = [];
    
    for (var i = 0; i < orders.length; i++) {
        if (orders[i].status === 'pending') {
            pendingOrders.push(orders[i]);
        }
    }
    
    var html = '<h4 style="margin-bottom:20px;">⏳ Pending Orders (' + pendingOrders.length + ')</h4>';
    
    if (pendingOrders.length === 0) {
        html += '<div style="text-align:center;padding:40px;">';
        html += '<div style="font-size:48px;">✅</div>';
        html += '<p style="color:#10b981;font-size:18px;">No pending orders!</p>';
        html += '</div>';
    } else {
        for (var j = 0; j < pendingOrders.length; j++) {
            var order = pendingOrders[j];
            
            html += '<div class="order-card" style="border-left:4px solid #f59e0b;margin-bottom:15px;">';
            
            html += '<div style="display:flex;justify-content:space-between;">';
            html += '<h4>#' + order.id + '</h4>';
            html += '<span style="color:#f59e0b;font-weight:bold;">⏳ PENDING</span>';
            html += '</div>';
            
            html += '<small style="color:#94a3b8;">📅 ' + order.date + '</small>';
            
            if (order.userUpiId) {
                html += '<p style="color:#94a3b8;">👤 Customer UPI: ' + order.userUpiId + '</p>';
            }
            
            html += '<div style="background:#0f172a;padding:12px;border-radius:8px;margin:12px 0;">';
            for (var k = 0; k < order.items.length; k++) {
                var item = order.items[k];
                html += '<div style="display:flex;justify-content:space-between;padding:3px 0;">';
                html += '<span>' + item.icon + ' ' + item.name + ' × ' + item.qty + '</span>';
                html += '<span style="color:#3b82f6;">₹' + (item.price * item.qty) + '</span>';
                html += '</div>';
            }
            html += '<hr style="border-color:#334155;margin:8px 0;">';
            html += '<div style="display:flex;justify-content:space-between;">';
            html += '<strong>Total:</strong>';
            html += '<strong style="color:#10b981;font-size:18px;">₹' + order.total + '</strong>';
            html += '</div></div>';
            
            if (order.screenshot) {
                html += '<div style="margin:10px 0;">';
                html += '<strong style="color:#94a3b8;">Payment Proof:</strong><br>';
                html += '<img src="' + order.screenshot + '" style="max-width:200px;border-radius:8px;cursor:pointer;border:1px solid #334155;" onclick="window.open(this.src)">';
                html += '</div>';
            } else {
                html += '<p style="color:#ef4444;">⚠️ No screenshot uploaded!</p>';
            }
            
            html += '<div style="display:flex;gap:10px;margin-top:15px;">';
            html += '<button onclick="approveOrder(\'' + order.id + '\')" style="background:#10b981;color:white;border:none;padding:12px;border-radius:8px;flex:1;cursor:pointer;font-weight:bold;">✅ Approve</button>';
            html += '<button onclick="rejectOrder(\'' + order.id + '\')" style="background:#ef4444;color:white;border:none;padding:12px;border-radius:8px;flex:1;cursor:pointer;">❌ Reject</button>';
            html += '</div>';
            
            html += '</div>';
        }
    }
    
    content.innerHTML = html;
}

// ========== APPROVE ORDER ==========
function approveOrder(orderId) {
    if (!confirm('✅ Approve this payment? Customer will be able to download files.')) return;
    
    var order = null;
    for (var i = 0; i < orders.length; i++) {
        if (orders[i].id === orderId) {
            order = orders[i];
            break;
        }
    }
    
    if (order) {
        order.status = 'approved';
        order.approvedAt = new Date().toLocaleString();
        saveAll();
        showAdminOrders();
        showNotif('✅ Order #' + orderId + ' approved!', 'success');
    }
}

// ========== REJECT ORDER ==========
function rejectOrder(orderId) {
    var reason = prompt('❌ Reason for rejection:');
    if (!reason) return;
    
    var order = null;
    for (var i = 0; i < orders.length; i++) {
        if (orders[i].id === orderId) {
            order = orders[i];
            break;
        }
    }
    
    if (order) {
        order.status = 'rejected';
        order.reason = reason;
        order.rejectedAt = new Date().toLocaleString();
        saveAll();
        showAdminOrders();
        showNotif('❌ Order #' + orderId + ' rejected', 'error');
    }
}

// ========== ADMIN PRODUCTS ==========
function showAdminProducts() {
    var content = document.getElementById('adminContent');
    
    var html = '';
    html += '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">';
    html += '<h4>📦 Total Products: ' + products.length + '</h4>';
    html += '<button onclick="showProductForm()" style="background:#10b981;color:white;border:none;padding:10px 20px;border-radius:8px;cursor:pointer;font-weight:bold;">+ Add New Product</button>';
    html += '</div>';
    
    for (var i = 0; i < products.length; i++) {
        var p = products[i];
        
        html += '<div class="order-card" style="display:flex;justify-content:space-between;align-items:center;">';
        html += '<div style="display:flex;align-items:center;gap:15px;">';
        html += '<div style="font-size:40px;">' + p.icon + '</div>';
        html += '<div>';
        html += '<h4>' + p.name + '</h4>';
        html += '<span class="product-category">' + p.category.toUpperCase() + '</span>';
        html += '<p style="color:#94a3b8;font-size:14px;">' + p.desc + '</p>';
        html += '<p>';
        html += '<span style="color:#3b82f6;font-size:18px;font-weight:bold;">₹' + (p.salePrice || p.price) + '</span>';
        if (p.salePrice) {
            html += '<span class="old-price">₹' + p.price + '</span>';
        }
        if (p.featured) {
            html += '<span style="color:#f59e0b;margin-left:10px;">⭐ Featured</span>';
        }
        if (p.downloadLink) {
            html += '<span style="color:#10b981;margin-left:10px;">🔗 Has Link</span>';
        } else {
            html += '<span style="color:#ef4444;margin-left:10px;">⚠️ No Link</span>';
        }
        html += '</p>';
        html += '</div></div>';
        
        html += '<div style="display:flex;gap:10px;">';
        html += '<button onclick="showProductForm(' + p.id + ')" style="background:#3b82f6;color:white;border:none;padding:8px 15px;border-radius:6px;cursor:pointer;">✏️ Edit</button>';
        html += '<button onclick="deleteProduct(' + p.id + ')" style="background:#ef4444;color:white;border:none;padding:8px 15px;border-radius:6px;cursor:pointer;">🗑️ Delete</button>';
        html += '</div>';
        html += '</div>';
    }
    
    content.innerHTML = html;
}

// ========== PRODUCT FORM (Add/Edit) ==========
function showProductForm(productId) {
    var product = null;
    if (productId) {
        for (var i = 0; i < products.length; i++) {
            if (products[i].id === productId) {
                product = products[i];
                break;
            }
        }
    }
    
    var isEdit = (product !== null);
    
    var modal = document.createElement('div');
    modal.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.85);z-index:2000;display:flex;justify-content:center;align-items:center;padding:20px;';
    modal.id = 'productFormModal';
    
    var html = '';
    html += '<div style="background:#1e293b;padding:25px;border-radius:12px;max-width:500px;width:100%;max-height:80vh;overflow-y:auto;">';
    
    // Title
    html += '<h3 style="color:#3b82f6;margin-bottom:20px;">';
    html += isEdit ? '✏️ Edit Product' : '➕ Add New Product';
    html += '</h3>';
    
    // Product Name
    html += '<div class="form-group">';
    html += '<label>Product Name *</label>';
    html += '<input type="text" id="prodName" value="' + (product ? product.name : '') + '" style="width:100%;padding:10px;background:#0f172a;border:1px solid #334155;color:white;border-radius:6px;">';
    html += '</div>';
    
    // Category
    html += '<div class="form-group">';
    html += '<label>Category *</label>';
    html += '<select id="prodCategory" style="width:100%;padding:10px;background:#0f172a;border:1px solid #334155;color:white;border-radius:6px;">';
    html += '<option value="html"' + (product && product.category === 'html' ? ' selected' : '') + '>HTML Templates</option>';
    html += '<option value="react"' + (product && product.category === 'react' ? ' selected' : '') + '>React Projects</option>';
    html += '<option value="game"' + (product && product.category === 'game' ? ' selected' : '') + '>Games</option>';
    html += '<option value="tool"' + (product && product.category === 'tool' ? ' selected' : '') + '>Tools</option>';
    html += '</select>';
    html += '</div>';
    
    // Description
    html += '<div class="form-group">';
    html += '<label>Description</label>';
    html += '<textarea id="prodDesc" rows="3" style="width:100%;padding:10px;background:#0f172a;border:1px solid #334155;color:white;border-radius:6px;">' + (product ? product.desc : '') + '</textarea>';
    html += '</div>';
    
    // Icon
    html += '<div class="form-group">';
    html += '<label>Icon (Emoji) *</label>';
    html += '<input type="text" id="prodIcon" value="' + (product ? product.icon : '📦') + '" style="width:100%;padding:10px;background:#0f172a;border:1px solid #334155;color:white;border-radius:6px;">';
    html += '</div>';
    
    // Price & Sale Price
    html += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">';
    html += '<div class="form-group">';
    html += '<label>Price (₹) *</label>';
    html += '<input type="number" id="prodPrice" value="' + (product ? product.price : '') + '" style="width:100%;padding:10px;background:#0f172a;border:1px solid #334155;color:white;border-radius:6px;">';
    html += '</div>';
    html += '<div class="form-group">';
    html += '<label>Sale Price (₹)</label>';
    html += '<input type="number" id="prodSalePrice" value="' + (product && product.salePrice ? product.salePrice : '') + '" style="width:100%;padding:10px;background:#0f172a;border:1px solid #334155;color:white;border-radius:6px;">';
    html += '</div>';
    html += '</div>';
    
    // File Name
    html += '<div class="form-group">';
    html += '<label>File Name</label>';
    html += '<input type="text" id="prodFile" value="' + (product ? product.file : '') + '" placeholder="e.g., template.zip" style="width:100%;padding:10px;background:#0f172a;border:1px solid #334155;color:white;border-radius:6px;">';
    html += '</div>';
    
    // Download Link (Google Drive)
    html += '<div class="form-group">';
    html += '<label>Download Link (Google Drive) *</label>';
    html += '<input type="text" id="prodDownloadLink" value="' + (product ? (product.downloadLink || '') : '') + '" placeholder="https://drive.google.com/file/d/..." style="width:100%;padding:10px;background:#0f172a;border:1px solid #334155;color:white;border-radius:6px;">';
    html += '<small style="color:#f59e0b;">⚠️ Upload ZIP to Google Drive → Share → Copy Link → Paste here</small>';
    html += '</div>';
    
    // Featured Checkbox
    html += '<div class="form-group">';
    html += '<label>';
    html += '<input type="checkbox" id="prodFeatured"' + (product && product.featured ? ' checked' : '') + ' style="margin-right:8px;">';
    html += 'Featured Product';
    html += '</label>';
    html += '</div>';
    
    // Buttons
    html += '<div style="display:flex;gap:10px;margin-top:20px;">';
    if (isEdit) {
        html += '<button onclick="updateProduct(' + productId + ')" style="background:#10b981;color:white;border:none;padding:12px;border-radius:8px;flex:1;cursor:pointer;font-weight:bold;">✅ Update Product</button>';
    } else {
        html += '<button onclick="addNewProduct()" style="background:#10b981;color:white;border:none;padding:12px;border-radius:8px;flex:1;cursor:pointer;font-weight:bold;">✅ Add Product</button>';
    }
    html += '<button onclick="closeProductForm()" style="background:#334155;color:white;border:none;padding:12px;border-radius:8px;flex:1;cursor:pointer;">Cancel</button>';
    html += '</div>';
    
    html += '</div>';
    
    modal.innerHTML = html;
    document.body.appendChild(modal);
    
    modal.addEventListener('click', function(e) {
        if (e.target === modal) {
            modal.remove();
        }
    });
}

function closeProductForm() {
    var modal = document.getElementById('productFormModal');
    if (modal) modal.remove();
}

// ========== ADD NEW PRODUCT ==========
function addNewProduct() {
    var name = document.getElementById('prodName').value.trim();
    var category = document.getElementById('prodCategory').value;
    var desc = document.getElementById('prodDesc').value.trim();
    var icon = document.getElementById('prodIcon').value.trim() || '📦';
    var price = parseFloat(document.getElementById('prodPrice').value);
    var salePriceValue = document.getElementById('prodSalePrice').value;
    var file = document.getElementById('prodFile').value.trim();
    var downloadLink = document.getElementById('prodDownloadLink').value.trim();
    var featured = document.getElementById('prodFeatured').checked;
    
    if (!name || !price) {
        showNotif('Please fill Name and Price!', 'error');
        return;
    }
    
    if (!downloadLink) {
        showNotif('⚠️ Please add Google Drive download link!', 'error');
        return;
    }
    
    var newProduct = {
        id: Date.now(),
        name: name,
        category: category,
        desc: desc || 'No description',
        price: price,
        salePrice: salePriceValue ? parseFloat(salePriceValue) : null,
        icon: icon,
        featured: featured,
        file: file || 'product.zip',
        downloadLink: downloadLink
    };
    
    products.push(newProduct);
    saveAll();
    closeProductForm();
    showAdminProducts();
    showProducts();
    showNotif('✅ Product added successfully!', 'success');
}
// ========== UPDATE PRODUCT ==========
function updateProduct(productId) {
    var index = -1;
    for (var i = 0; i < products.length; i++) {
        if (products[i].id === productId) {
            index = i;
            break;
        }
    }
    
    if (index === -1) return;
    
    var name = document.getElementById('prodName').value.trim();
    var category = document.getElementById('prodCategory').value;
    var desc = document.getElementById('prodDesc').value.trim();
    var icon = document.getElementById('prodIcon').value.trim() || '📦';
    var price = parseFloat(document.getElementById('prodPrice').value);
    var salePriceValue = document.getElementById('prodSalePrice').value;
    var file = document.getElementById('prodFile').value.trim();
    var downloadLink = document.getElementById('prodDownloadLink').value.trim();
    var featured = document.getElementById('prodFeatured').checked;
    
    if (!name || !price) {
        showNotif('Please fill Name and Price!', 'error');
        return;
    }
    
    products[index].name = name;
    products[index].category = category;
    products[index].desc = desc || 'No description';
    products[index].price = price;
    products[index].salePrice = salePriceValue ? parseFloat(salePriceValue) : null;
    products[index].icon = icon;
    products[index].featured = featured;
    products[index].file = file || products[index].file;
    products[index].downloadLink = downloadLink || products[index].downloadLink || '';
    
    saveAll();
    closeProductForm();
    showAdminProducts();
    showProducts();
    showNotif('✅ Product updated!', 'success');
}

// ========== DELETE PRODUCT ==========
function deleteProduct(productId) {
    var product = null;
    for (var i = 0; i < products.length; i++) {
        if (products[i].id === productId) {
            product = products[i];
            break;
        }
    }
    
    if (!product) return;
    
    if (!confirm('Delete "' + product.name + '"?\n\nThis cannot be undone!')) return;
    
    var newProducts = [];
    for (var j = 0; j < products.length; j++) {
        if (products[j].id !== productId) {
            newProducts.push(products[j]);
        }
    }
    products = newProducts;
    
    saveAll();
    showAdminProducts();
    showProducts();
    showNotif('🗑️ Product deleted!', 'error');
}

// ========== ADMIN USERS ==========
function showAdminUsers() {
    var content = document.getElementById('adminContent');
    
    var html = '<h4 style="margin-bottom:20px;">👥 Users (' + users.length + ')</h4>';
    
    if (users.length === 0) {
        html += '<p style="color:#94a3b8;">No users registered</p>';
    } else {
        html += '<div style="overflow-x:auto;"><table style="width:100%;border-collapse:collapse;">';
        html += '<thead><tr style="background:#334155;">';
        html += '<th style="padding:10px;">Name</th>';
        html += '<th style="padding:10px;">Email</th>';
        html += '<th style="padding:10px;">Phone</th>';
        html += '<th style="padding:10px;">Orders</th>';
        html += '<th style="padding:10px;">Join Date</th>';
        html += '</tr></thead><tbody>';
        
        for (var i = 0; i < users.length; i++) {
            var u = users[i];
            html += '<tr style="border-bottom:1px solid #334155;">';
            html += '<td style="padding:10px;">' + u.name + (u.isAdmin ? ' 👑' : '') + '</td>';
            html += '<td style="padding:10px;">' + u.email + '</td>';
            html += '<td style="padding:10px;">' + u.phone + '</td>';
            html += '<td style="padding:10px;">' + (u.totalOrders || 0) + '</td>';
            html += '<td style="padding:10px;">' + u.joinDate + '</td>';
            html += '</tr>';
        }
        
        html += '</tbody></table></div>';
    }
    
    content.innerHTML = html;
}

// ========== ADMIN STATS ==========
function showAdminStats() {
    var content = document.getElementById('adminContent');
    
    var totalOrders = orders.length;
    var pendingOrders = 0;
    var approvedOrders = 0;
    var rejectedOrders = 0;
    var totalRevenue = 0;
    
    for (var i = 0; i < orders.length; i++) {
        if (orders[i].status === 'pending') pendingOrders++;
        if (orders[i].status === 'approved') {
            approvedOrders++;
            totalRevenue = totalRevenue + orders[i].total;
        }
        if (orders[i].status === 'rejected') rejectedOrders++;
    }
    
    var html = '';
    
    // Stats Cards
    html += '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:15px;margin-bottom:20px;">';
    
    html += '<div style="background:#1e293b;padding:20px;border-radius:12px;text-align:center;border:1px solid #334155;">';
    html += '<div style="font-size:40px;">📦</div>';
    html += '<h2 style="color:white;">' + totalOrders + '</h2>';
    html += '<p style="color:#94a3b8;">Total Orders</p>';
    html += '</div>';
    
    html += '<div style="background:#1e293b;padding:20px;border-radius:12px;text-align:center;border:1px solid #334155;">';
    html += '<div style="font-size:40px;">📚</div>';
    html += '<h2 style="color:white;">' + products.length + '</h2>';
    html += '<p style="color:#94a3b8;">Products</p>';
    html += '</div>';
    
    html += '<div style="background:#1e293b;padding:20px;border-radius:12px;text-align:center;border:1px solid #334155;">';
    html += '<div style="font-size:40px;">💰</div>';
    html += '<h2 style="color:#10b981;">₹' + totalRevenue + '</h2>';
    html += '<p style="color:#94a3b8;">Total Revenue</p>';
    html += '</div>';
    
    html += '<div style="background:#1e293b;padding:20px;border-radius:12px;text-align:center;border:1px solid #334155;">';
    html += '<div style="font-size:40px;">👥</div>';
    html += '<h2 style="color:#3b82f6;">' + users.length + '</h2>';
    html += '<p style="color:#94a3b8;">Users</p>';
    html += '</div>';
    
    html += '</div>';
    
    // Recent Orders
    html += '<div style="background:#1e293b;padding:20px;border-radius:12px;border:1px solid #334155;">';
    html += '<h4 style="margin-bottom:15px;">📊 Recent Orders</h4>';
    
    if (orders.length === 0) {
        html += '<p style="color:#94a3b8;">No orders yet</p>';
    } else {
        var recentOrders = orders.slice(0, 5);
        for (var j = 0; j < recentOrders.length; j++) {
            var order = recentOrders[j];
            var statusColor = order.status === 'approved' ? '#10b981' : order.status === 'pending' ? '#f59e0b' : '#ef4444';
            
            html += '<div style="display:flex;justify-content:space-between;align-items:center;padding:10px 0;border-bottom:1px solid #334155;">';
            html += '<div>';
            html += '<span style="color:#3b82f6;">#' + order.id + '</span>';
            html += '<br><small style="color:#94a3b8;">' + order.date + '</small>';
            html += '</div>';
            html += '<span style="color:#10b981;">₹' + order.total + '</span>';
            html += '<span style="color:' + statusColor + ';font-weight:bold;">' + order.status.toUpperCase() + '</span>';
            html += '</div>';
        }
    }
    
    html += '</div>';
    
    content.innerHTML = html;
}

// ========== INITIALIZATION ==========
window.onload = function() {
    if (sessionStorage.getItem('nsAdminLogin') === 'true') {
        adminLoggedIn = true;
        document.getElementById('adminBtn').textContent = '🔓 Exit Admin';
        document.getElementById('adminBtn').style.background = '#10b981';
    }
    
    showProducts();
    updateCartUI();
};

console.log('🚀 NS Code Store Ready!');
console.log('📦 Products:', products.length);
console.log('🛒 Cart Items:', cart.length);
console.log('📋 Orders:', orders.length);
console.log('👥 Users:', users.length);
console.log('🔑 Admin Password:', ADMIN_PASSWORD);