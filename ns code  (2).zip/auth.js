// ==========================================
// NS CODE STORE - Auth System
// ==========================================

// Current logged in user
let currentUser = JSON.parse(localStorage.getItem('nsCurrentUser')) || null;

// All users list
let users = JSON.parse(localStorage.getItem('nsAllUsers')) || [];

// Admin user add karo agar nahi hai
function initAdmin() {
    var adminExists = false;
    for (var i = 0; i < users.length; i++) {
        if (users[i].isAdmin) {
            adminExists = true;
            break;
        }
    }
    
    if (!adminExists) {
        users.push({
            id: 'admin_' + Date.now(),
            name: 'Store Admin',
            email: 'admin@nscodestore.com',
            phone: '0000000000',
            password: 'nsadmin123',
            avatar: '',
            joinDate: new Date().toLocaleDateString(),
            totalSpent: 0,
            totalOrders: 0,
            isAdmin: true,
            emailVerified: true
        });
        saveUsers();
    }
}

// Save users to localStorage
function saveUsers() {
    localStorage.setItem('nsAllUsers', JSON.stringify(users));
}

// Save current user
function saveCurrentUser() {
    if (currentUser) {
        localStorage.setItem('nsCurrentUser', JSON.stringify(currentUser));
    } else {
        localStorage.removeItem('nsCurrentUser');
    }
    updateUserUI();
}

// ========== UPDATE UI FOR LOGGED IN USER ==========
function updateUserUI() {
    var userBtn = document.getElementById('userBtn');
    if (!userBtn) return;
    
    if (currentUser) {
        userBtn.textContent = '👤 ' + currentUser.name;
        userBtn.onclick = function() {
            showUserMenu();
        };
    } else {
        userBtn.textContent = '👤 Login';
        userBtn.onclick = function() {
            showAuthModal('login');
        };
    }
}

// ========== USER MENU DROPDOWN ==========
function showUserMenu() {
    if (!currentUser) {
        showAuthModal('login');
        return;
    }
    
    var menu = document.createElement('div');
    menu.id = 'userMenuDropdown';
    menu.style.cssText = 'position:fixed;top:60px;right:20px;background:#1e293b;border:1px solid #334155;border-radius:12px;padding:10px;z-index:1500;min-width:200px;box-shadow:0 10px 30px rgba(0,0,0,0.5);';
    
    menu.innerHTML = `
        <div style="padding:10px;border-bottom:1px solid #334155;">
            <strong>${currentUser.name}</strong>
            <br><small style="color:#94a3b8;">${currentUser.email}</small>
        </div>
        <button onclick="showPage('profile');closeUserMenu();" style="display:block;width:100%;padding:10px;background:none;border:none;color:white;text-align:left;cursor:pointer;border-radius:6px;">👤 My Profile</button>
        <button onclick="showPage('orders');closeUserMenu();" style="display:block;width:100%;padding:10px;background:none;border:none;color:white;text-align:left;cursor:pointer;border-radius:6px;">📋 My Orders</button>
        <button onclick="showPage('wishlist');closeUserMenu();" style="display:block;width:100%;padding:10px;background:none;border:none;color:white;text-align:left;cursor:pointer;border-radius:6px;">❤️ Wishlist</button>
        <hr style="border-color:#334155;margin:5px 0;">
        <button onclick="logout();closeUserMenu();" style="display:block;width:100%;padding:10px;background:#ef4444;border:none;color:white;text-align:center;cursor:pointer;border-radius:6px;">🚪 Logout</button>
    `;
    
    document.body.appendChild(menu);
    
    // Close menu on outside click
    setTimeout(function() {
        document.addEventListener('click', function closeMenu(e) {
            if (!menu.contains(e.target)) {
                menu.remove();
                document.removeEventListener('click', closeMenu);
            }
        });
    }, 100);
}

function closeUserMenu() {
    var menu = document.getElementById('userMenuDropdown');
    if (menu) menu.remove();
}

// ========== LOGOUT ==========
function logout() {
    currentUser = null;
    saveCurrentUser();
    cart = [];
    saveAll();
    updateCartUI();
    showPage('home');
    showNotif('Logged out successfully!', 'info');
}

// ========== HANDLE USER BUTTON CLICK ==========
function handleUserClick() {
    if (currentUser) {
        showUserMenu();
    } else {
        showAuthModal('login');
    }
}

// ========== SHOW AUTH MODAL ==========
function showAuthModal(mode) {
    var modal = document.getElementById('authModal');
    var title = document.getElementById('authTitle');
    var content = document.getElementById('authContent');
    
    if (mode === 'login') {
        title.textContent = '🔐 Login';
        content.innerHTML = getLoginForm();
    } else {
        title.textContent = '📝 Register';
        content.innerHTML = getRegisterForm();
    }
    
    modal.classList.add('active');
}

function closeAuth() {
    document.getElementById('authModal').classList.remove('active');
}

// ========== LOGIN FORM ==========
function getLoginForm() {
    return `
        <div class="form-group">
            <label>Email</label>
            <input type="email" id="loginEmail" placeholder="Enter your email">
        </div>
        <div class="form-group">
            <label>Password</label>
            <input type="password" id="loginPassword" placeholder="Enter password">
        </div>
        <p id="loginError" style="color:#ef4444;display:none;margin-bottom:10px;"></p>
        <button onclick="loginUser()" class="auth-btn btn-success">Login</button>
        <p style="text-align:center;margin-top:15px;color:#94a3b8;">
            Don't have an account? 
            <span class="auth-link" onclick="showAuthModal('register')">Register here</span>
        </p>
        <p style="text-align:center;color:#64748b;font-size:12px;margin-top:10px;">
            Admin Login: admin@nscodestore.com / nsadmin123
        </p>
    `;
}

// ========== REGISTER FORM ==========
function getRegisterForm() {
    return `
        <div class="form-group">
            <label>Full Name *</label>
            <input type="text" id="regName" placeholder="Enter full name">
        </div>
        <div class="form-group">
            <label>Email *</label>
            <input type="email" id="regEmail" placeholder="Enter email">
        </div>
        <div class="form-group">
            <label>Phone Number</label>
            <input type="tel" id="regPhone" placeholder="Enter phone number">
        </div>
        <div class="form-group">
            <label>Password *</label>
            <input type="password" id="regPassword" placeholder="Min 6 characters">
        </div>
        <div class="form-group">
            <label>Confirm Password *</label>
            <input type="password" id="regConfirmPassword" placeholder="Re-enter password">
        </div>
        <p id="regError" style="color:#ef4444;display:none;margin-bottom:10px;"></p>
        <button onclick="registerUser()" class="auth-btn btn-primary">Create Account</button>
        <p style="text-align:center;margin-top:15px;color:#94a3b8;">
            Already have an account? 
            <span class="auth-link" onclick="showAuthModal('login')">Login here</span>
        </p>
    `;
}

// ========== LOGIN USER ==========
function loginUser() {
    var email = document.getElementById('loginEmail').value.trim().toLowerCase();
    var password = document.getElementById('loginPassword').value;
    var errorEl = document.getElementById('loginError');
    
    // Validation
    if (!email || !password) {
        errorEl.textContent = 'Please fill all fields!';
        errorEl.style.display = 'block';
        return;
    }
    
    // Find user
    var user = null;
    for (var i = 0; i < users.length; i++) {
        if (users[i].email.toLowerCase() === email && users[i].password === password) {
            user = users[i];
            break;
        }
    }
    
    if (!user) {
        errorEl.textContent = 'Invalid email or password!';
        errorEl.style.display = 'block';
        return;
    }
    
    // Login success
    currentUser = {
        id: user.id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        avatar: user.avatar,
        joinDate: user.joinDate,
        totalSpent: user.totalSpent,
        totalOrders: user.totalOrders,
        isAdmin: user.isAdmin,
        emailVerified: user.emailVerified
    };
    
    saveCurrentUser();
    
    // Load user's cart
    loadUserCart();
    
    closeAuth();
    showNotif('Welcome back, ' + user.name + '! 🎉', 'success');
    showPage('home');
}

// ========== REGISTER USER ==========
function registerUser() {
    var name = document.getElementById('regName').value.trim();
    var email = document.getElementById('regEmail').value.trim().toLowerCase();
    var phone = document.getElementById('regPhone').value.trim();
    var password = document.getElementById('regPassword').value;
    var confirmPassword = document.getElementById('regConfirmPassword').value;
    var errorEl = document.getElementById('regError');
    
    // Validations
    if (!name || !email || !password || !confirmPassword) {
        errorEl.textContent = 'Please fill all required fields!';
        errorEl.style.display = 'block';
        return;
    }
    
    if (name.length < 2) {
        errorEl.textContent = 'Name must be at least 2 characters!';
        errorEl.style.display = 'block';
        return;
    }
    
    if (password.length < 6) {
        errorEl.textContent = 'Password must be at least 6 characters!';
        errorEl.style.display = 'block';
        return;
    }
    
    if (password !== confirmPassword) {
        errorEl.textContent = 'Passwords do not match!';
        errorEl.style.display = 'block';
        return;
    }
    
    // Check email already exists
    for (var i = 0; i < users.length; i++) {
        if (users[i].email.toLowerCase() === email) {
            errorEl.textContent = 'Email already registered!';
            errorEl.style.display = 'block';
            return;
        }
    }
    
    // Create new user
    var newUser = {
        id: 'user_' + Date.now(),
        name: name,
        email: email,
        phone: phone || 'Not provided',
        password: password,
        avatar: '',
        joinDate: new Date().toLocaleDateString(),
        totalSpent: 0,
        totalOrders: 0,
        isAdmin: false,
        emailVerified: false
    };
    
    users.push(newUser);
    saveUsers();
    
    // Auto login
    currentUser = {
        id: newUser.id,
        name: newUser.name,
        email: newUser.email,
        phone: newUser.phone,
        avatar: newUser.avatar,
        joinDate: newUser.joinDate,
        totalSpent: newUser.totalSpent,
        totalOrders: newUser.totalOrders,
        isAdmin: newUser.isAdmin,
        emailVerified: newUser.emailVerified
    };
    
    saveCurrentUser();
    closeAuth();
    showNotif('Account created! Welcome, ' + name + '! 🎉', 'success');
    showPage('home');
}

// ========== LOAD USER CART ==========
function loadUserCart() {
    if (currentUser) {
        var userCart = localStorage.getItem('nsCart_' + currentUser.id);
        cart = userCart ? JSON.parse(userCart) : [];
    } else {
        cart = [];
    }
    saveAll();
    updateCartUI();
}

// Override saveAll to save user-specific cart
var originalSaveAll = saveAll;
saveAll = function() {
    originalSaveAll();
    if (currentUser) {
        localStorage.setItem('nsCart_' + currentUser.id, JSON.stringify(cart));
    }
};

// ========== SHOW PROFILE PAGE ==========
function showProfilePage() {
    if (!currentUser) {
        showAuthModal('login');
        return;
    }
    
    var content = document.getElementById('profileContent');
    
    // Get user orders
    var userOrders = [];
    for (var i = 0; i < orders.length; i++) {
        if (orders[i].userId === currentUser.id) {
            userOrders.push(orders[i]);
        }
    }
    
    var totalSpent = 0;
    for (var j = 0; j < userOrders.length; j++) {
        if (userOrders[j].status === 'approved') {
            totalSpent = totalSpent + userOrders[j].total;
        }
    }
    
    var avatarLetter = currentUser.name.charAt(0).toUpperCase();
    
    content.innerHTML = `
        <div class="profile-card">
            <div class="profile-header">
                <div class="profile-avatar">${avatarLetter}</div>
                <h3>${currentUser.name}</h3>
                <p style="color:#94a3b8;">${currentUser.email}</p>
                ${currentUser.emailVerified ? '<span style="color:#10b981;">✅ Verified</span>' : '<span style="color:#f59e0b;">⚠️ Not Verified</span>'}
            </div>
            
            <div class="profile-stats">
                <div class="stat-box">
                    <h3>${userOrders.length}</h3>
                    <p>Orders</p>
                </div>
                <div class="stat-box">
                    <h3>₹${totalSpent}</h3>
                    <p>Total Spent</p>
                </div>
                <div class="stat-box">
                    <h3>${currentUser.joinDate}</h3>
                    <p>Member Since</p>
                </div>
            </div>
            
            <div style="background:#0f172a;padding:15px;border-radius:8px;margin:15px 0;">
                <p><strong>📧 Email:</strong> ${currentUser.email}</p>
                <p><strong>📱 Phone:</strong> ${currentUser.phone}</p>
                <p><strong>🆔 User ID:</strong> ${currentUser.id}</p>
            </div>
            
            <div class="profile-actions">
                <button class="edit-profile-btn" onclick="editProfile()">✏️ Edit Profile</button>
                <button class="logout-btn" onclick="logout()">🚪 Logout</button>
            </div>
        </div>
    `;
}

// ========== EDIT PROFILE ==========
function editProfile() {
    if (!currentUser) return;
    
    var modal = document.createElement('div');
    modal.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.85);z-index:2000;display:flex;justify-content:center;align-items:center;';
    modal.id = 'editProfileModal';
    
    modal.innerHTML = `
        <div style="background:#1e293b;padding:30px;border-radius:12px;max-width:450px;width:90%;">
            <h3 style="color:#3b82f6;margin-bottom:20px;">✏️ Edit Profile</h3>
            
            <div class="form-group">
                <label>Name</label>
                <input type="text" id="editName" value="${currentUser.name}" style="width:100%;padding:10px;background:#0f172a;border:1px solid #334155;color:white;border-radius:6px;">
            </div>
            
            <div class="form-group">
                <label>Phone</label>
                <input type="tel" id="editPhone" value="${currentUser.phone}" style="width:100%;padding:10px;background:#0f172a;border:1px solid #334155;color:white;border-radius:6px;">
            </div>
            
            <div class="form-group">
                <label>New Password (leave blank to keep current)</label>
                <input type="password" id="editPassword" placeholder="New password" style="width:100%;padding:10px;background:#0f172a;border:1px solid #334155;color:white;border-radius:6px;">
            </div>
            
            <div style="display:flex;gap:10px;margin-top:20px;">
                <button onclick="saveProfile()" style="background:#10b981;color:white;border:none;padding:12px;border-radius:8px;flex:1;cursor:pointer;font-weight:bold;">💾 Save</button>
                <button onclick="document.getElementById('editProfileModal').remove()" style="background:#334155;color:white;border:none;padding:12px;border-radius:8px;flex:1;cursor:pointer;">Cancel</button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    modal.addEventListener('click', function(e) {
        if (e.target === modal) modal.remove();
    });
}

// ========== SAVE PROFILE ==========
function saveProfile() {
    var newName = document.getElementById('editName').value.trim();
    var newPhone = document.getElementById('editPhone').value.trim();
    var newPassword = document.getElementById('editPassword').value;
    
    if (!newName) {
        showNotif('Name cannot be empty!', 'error');
        return;
    }
    
    // Update current user
    currentUser.name = newName;
    currentUser.phone = newPhone || 'Not provided';
    
    // Update in users array
    for (var i = 0; i < users.length; i++) {
        if (users[i].id === currentUser.id) {
            users[i].name = newName;
            users[i].phone = newPhone || 'Not provided';
            if (newPassword && newPassword.length >= 6) {
                users[i].password = newPassword;
                currentUser.password = newPassword;
            }
            break;
        }
    }
    
    saveUsers();
    saveCurrentUser();
    
    document.getElementById('editProfileModal').remove();
    showProfilePage();
    showNotif('✅ Profile updated!', 'success');
}

// ========== SHOW WISHLIST PAGE ==========
function showWishlistPage() {
    if (!currentUser) {
        showAuthModal('login');
        return;
    }
    
    var wishlist = JSON.parse(localStorage.getItem('nsWishlist_' + currentUser.id)) || [];
    var content = document.getElementById('wishlistContent');
    
    if (wishlist.length === 0) {
        content.innerHTML = '<p style="text-align:center;color:#94a3b8;padding:40px;">❤️ Wishlist is empty</p>';
        return;
    }
    
    var html = '<div class="wishlist-grid">';
    for (var i = 0; i < wishlist.length; i++) {
        var product = null;
        for (var j = 0; j < products.length; j++) {
            if (products[j].id === wishlist[i]) {
                product = products[j];
                break;
            }
        }
        
        if (product) {
            html += `
                <div class="product-card wishlist-item">
                    <span class="heart-icon" onclick="removeFromWishlist(${product.id})">💔</span>
                    ${makeProductCard(product).replace('Add to Cart', 'Add to Cart')}
                </div>
            `;
        }
    }
    html += '</div>';
    
    content.innerHTML = html;
}

// ========== ADD TO WISHLIST ==========
function addToWishlist(productId) {
    if (!currentUser) {
        showAuthModal('login');
        return;
    }
    
    var wishlist = JSON.parse(localStorage.getItem('nsWishlist_' + currentUser.id)) || [];
    
    // Check if already in wishlist
    for (var i = 0; i < wishlist.length; i++) {
        if (wishlist[i] === productId) {
            showNotif('Already in wishlist!', 'info');
            return;
        }
    }
    
    wishlist.push(productId);
    localStorage.setItem('nsWishlist_' + currentUser.id, JSON.stringify(wishlist));
    showNotif('❤️ Added to wishlist!', 'success');
}

// ========== REMOVE FROM WISHLIST ==========
function removeFromWishlist(productId) {
    if (!currentUser) return;
    
    var wishlist = JSON.parse(localStorage.getItem('nsWishlist_' + currentUser.id)) || [];
    var newWishlist = [];
    
    for (var i = 0; i < wishlist.length; i++) {
        if (wishlist[i] !== productId) {
            newWishlist.push(wishlist[i]);
        }
    }
    
    localStorage.setItem('nsWishlist_' + currentUser.id, JSON.stringify(newWishlist));
    showWishlistPage();
    showNotif('Removed from wishlist', 'info');
}
// ========== OVERRIDE SHOW PAGE FOR PROFILE & WISHLIST ==========
var originalShowPage = showPage;
showPage = function(page) {
    if (page === 'profile') {
        document.querySelectorAll('.page').forEach(function(p) { p.classList.remove('active'); });
        document.getElementById('profilePage').classList.add('active');
        showProfilePage();
        return;
    }
    
    if (page === 'wishlist') {
        document.querySelectorAll('.page').forEach(function(p) { p.classList.remove('active'); });
        document.getElementById('wishlistPage').classList.add('active');
        showWishlistPage();
        return;
    }
    
    originalShowPage(page);
};

// ========== OVERRIDE SUBMIT ORDER FOR USER ID ==========
var originalSubmitOrder = submitOrder;
submitOrder = function() {
    if (!currentUser) {
        showNotif('Please login first!', 'error');
        showAuthModal('login');
        closeCheckout();
        return;
    }
    originalSubmitOrder();
    
    // Add userId to last order
    if (orders.length > 0) {
        orders[0].userId = currentUser.id;
        
        // Update user stats
        currentUser.totalOrders = (currentUser.totalOrders || 0) + 1;
        
        // Update in users array
        for (var i = 0; i < users.length; i++) {
            if (users[i].id === currentUser.id) {
                users[i].totalOrders = currentUser.totalOrders;
                break;
            }
        }
        
        saveUsers();
        saveCurrentUser();
        saveAll();
    }
};

// ========== OVERRIDE SHOW MY ORDERS ==========
var originalShowMyOrders = showMyOrders;
showMyOrders = function() {
    if (!currentUser) {
        showAuthModal('login');
        return;
    }
    
    var container = document.getElementById('myOrdersList');
    if (!container) return;
    
    // Filter orders for current user
    var userOrders = [];
    for (var i = 0; i < orders.length; i++) {
        if (orders[i].userId === currentUser.id) {
            userOrders.push(orders[i]);
        }
    }
    
    if (userOrders.length === 0) {
        container.innerHTML = '<p style="text-align:center;color:#94a3b8;padding:30px;">No orders yet</p>';
        return;
    }
    
    var tempOrders = orders;
    orders = userOrders;
    originalShowMyOrders();
    orders = tempOrders;
};

// ========== INITIALIZE ==========
initAdmin();
updateUserUI();

// Check if user was logged in
if (currentUser) {
    loadUserCart();
    updateUserUI();
}

console.log('🔐 Auth System Ready');
console.log('👤 Current User:', currentUser ? currentUser.name : 'None');
console.log('👥 Total Users:', users.length);